public interface SpecialPoint {
    int getX();
    int getY();

}
