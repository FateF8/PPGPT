public class Test {

    public static void main(String[] args) {

        /*
        Arbeitsverteilung Aufgabe 1:
        Alle zusammen: erstes Konzept, Implementierung der Klassen Ant und Simulation
        Gao Julian: Grundgerüst, Implementierung der Klassen FoodSource, SingleFieldInfo, Scent und Anthill
        Xu Lucy: Ideenbeisteuerung & Implementierung Duftspur
        Yi Yan: Ideenbeisteuerung & Implementierung Bewegung (directions, boundaries) der Ameisen


        Wir haben fast immer zusammen auf Discord geredet und das Beispiel entwickelt,
        meistens hat nur eine Person aktiv programmiert, während die anderen über Bildschirm-
        übertragung zugesehen und Ideen eingebracht haben bzw. es wurde an verschiedenen
        Problemen individuell gearbeitet.

         */
        Simulation simulation = new Simulation();
        while(true) {
            simulation.antsMove();
            simulation.draw();
        }
    }

}
